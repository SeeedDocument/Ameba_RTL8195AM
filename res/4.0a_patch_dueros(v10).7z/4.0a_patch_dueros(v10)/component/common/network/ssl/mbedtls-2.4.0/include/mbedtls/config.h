#define CONFIG_SSL_RSA          0
#define CONFIG_SSL_CUSTOMER 1

#include "rom_ssl_ram_map.h"
#include "platform_stdlib.h"

#if CONFIG_SSL_RSA
#define RTL_HW_CRYPTO
//#define SUPPORT_HW_SW_CRYPTO
#define RTL_CRYPTO_FRAGMENT               15360 /* 15*1024 < 16000 */
#include "mbedtls/config_rsa.h"
#elif CONFIG_SSL_CUSTOMER
#include "baidu_ca_mbedtls_config.h"
#else
#define RTL_HW_CRYPTO
//#define SUPPORT_HW_SW_CRYPTO
#define RTL_CRYPTO_FRAGMENT               15360 /* 15*1024 < 16000 */
#include "mbedtls/config_all.h"
#endif
