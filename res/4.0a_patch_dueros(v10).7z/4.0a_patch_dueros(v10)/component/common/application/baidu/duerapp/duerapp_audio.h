#include "FreeRTOS.h"
#include "task.h"
#include "section_config.h"
#include "osdep_service.h"
#include <platform_stdlib.h>

#include "dma_api.h"
#include "i2s_api.h"
#include "gpio_api.h"
#include "gpio_irq_api.h"
#include "timer_api.h"

#include "duerapp_config.h"
#include "queue.h"

#define SDRAM_BSS_SECTION	SECTION(".sdram.bss")
#define SDRAM_DATA_SECTION	SECTION(".sdram.data")
#define RECORD_LEN_SEC 8
#define RECORD_LEN (32*1000*RECORD_LEN_SEC)

#define I2S_MAX_DMA_PAGE_SIZE	4608
#define I2S_DMA_PAGE_NUM    4   // Vaild number is 2~4
#define I2S_FREQ_NUM 7

#define LED_TIME_PERIOD 500000  //500MS
#define led_off 1
#define led_on  0

#define GPIO_IRQ_PIN            PC_5
#define I2S_SCLK_PIN            PC_1
#define I2S_WS_PIN              PC_0
#define I2S_SD_PIN              PC_2

#define RECORD_DELAY(_x)    ((_x) * 20 * 10000 / RECORD_FARME_SIZE / 10000)

#define AUDIO_RX_IDLE             (0)
#define AUDIO_RX_EARLY_PROCESSING (1)
#define AUDIO_RX_PROCESSING       (2)
#define AUDIO_RX_END              (3)
#define I2S_RX_HISTORY_SIZE (25)
#define I2S_RX_PAGE_SIZE	640  //(640bytes * 8bits/byte)/(16K samples/second * 16bits/sample) = 20ms

#define SKIP_PAGE_NUM 0//16000/I2S_RX_PAGE_SIZE

typedef struct record_s{
	u32 skip_pages;
	
	long int bkg_avg_vol;
	int volume_max;
	u8 silent_count;
	u8 is_recording;

	long int total_cmd_vol;
	long int cmd_vol_count;
	
	u32 audio_record_start_timestamp;
	u32 audio_record_timeout;

	u32 record_length;
	u32 i2s_rx_history_idx;
}record_t;

typedef struct record_para_s{
	u32 avg_vol_level;
	u32 max_silent_cnt;
	u32 base_vol_thres;
	u32 vol_up_thres;
	bool detect_voice_stop;
}record_para_t;

typedef struct player_s{
    int nb_channels;
    int sample_rate;
	int frame_size;
}player_t;

typedef enum {
	TONE_HELLO = 0,
	TONE_CANNOTPLAY = 1,
	TONE_CANNOTHEARD = 2,
	TONE_DUERSTOPPED = 3,
	TONE_MAX,
}Tones;


extern int is_audio_need_pause(void);
extern void audio_play_pause_resume(void);
extern void initialize_audio(void);

