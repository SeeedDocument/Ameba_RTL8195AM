
/**
  * @brief  Execute some operations when start to record
  * @param  timeout_ms: Period to be silent before stop recording
  * @retval None
  * @Note   It is necessary to set audio_is_pocessing to 1 in this function
  */
void audio_record_start(uint32_t timeout_ms);

/**
  * @brief  Execute some operations when stop recording
  * @param  None
  * @retval None
  * @Note   It is necessary to reset audio_is_pocessing to 0 in this function
  */
void audio_record_stop();

/**
  * @brief  Initializes the interface with codec to be able to rx data
  * @param  None
  * @retval 0: Init success
  */
int initialize_audio_as_recorder();

u32 get_base_vol_threshold();
void set_base_vol_threshold(u32 value);
u32 get_vol_up_threshold();
void set_vol_up_threshold(u32 value);
u32 get_max_silent_cnt();
void set_max_silent_cnt(u32 value);
u32 get_detect_voice_stop();
void set_detect_voice_stop(bool state);

