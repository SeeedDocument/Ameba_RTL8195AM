#include "duerapp_audio.h"
#include "mp3/mp3_codec.h"

mp3_decoder_t mp3 = NULL;
u8 audio_is_pocessing = 0;
signed short pcm_buf[I2S_MAX_DMA_PAGE_SIZE];

extern int duer_mp3_play_stop;
extern u8 audio_is_playing;
extern u8 duer_engine_is_stopped;
extern void play_tone_thread(void* param);
extern void tone_enqueue(Tones tone);
extern int initialize_audio_as_recorder();

static int need_pause_audio = 0;
static _sema audio_pause_sema = NULL;
static _sema audio_resume_sema = NULL;

extern _sema i2s_rx_sema;
extern void i2s_rx_thread(void* param);


u8 voice_is_triggered = 0;  //From voice triggered to play hello done, voice_is_triggered = 1; else, voice_is_triggered= 0

void play_tone_pause_audio()
{
	DUER_LOGD("play_tone_pause_audio(): audio_is_playing %d\n", audio_is_playing);

	while(audio_is_playing){
		need_pause_audio = 1;
		if(rtw_down_timeout_sema(&audio_pause_sema,50) == pdTRUE)
			break;
	}

	if(audio_is_playing == 0)
		need_pause_audio = 0;
}

void play_tone_resume_audio()
{
	DUER_LOGD("play_tone_resume_audio(): need_pause_audio %d\n", need_pause_audio);
	if(need_pause_audio == 1){
		need_pause_audio = 0;
		rtw_up_sema(&audio_resume_sema);
	}
}

int is_audio_need_pause()
{
	return need_pause_audio;
}

void audio_play_pause_resume()
{
	DUER_LOGD("audio_play_pause_resume(): Paused\n");
	rtw_up_sema(&audio_pause_sema);
	rtw_down_sema(&audio_resume_sema);
	DUER_LOGD("audio_play_pause_resume(): Resumed\n");
}

void voice_trigger_irq_handler (uint32_t id, gpio_irq_event event)
{
	DUER_LOGI("voice irq");

    //duer_engine is stopped
    if(duer_engine_is_stopped == 1){
        voice_is_triggered = 1;
		tone_enqueue(TONE_DUERSTOPPED);
        return;
    }

	if(audio_is_playing == 1){
		duer_mp3_play_stop = 1;
		DUER_LOGI("Stop music");
		return;
	}

	if(audio_is_pocessing == 0){
		voice_is_triggered = 1;
		tone_enqueue(TONE_HELLO);
	}
    
}

void initialize_audio(void)
{
	DUER_LOGI("Initializing audio codec....\n");

	gpio_irq_t voice_irq;

	//init voice trigger pin
	gpio_irq_init(&voice_irq, GPIO_IRQ_PIN, voice_trigger_irq_handler, NULL);
	gpio_irq_set(&voice_irq, IRQ_RISE, 1);
	gpio_irq_enable(&voice_irq);

	//init interface with codec
	rtw_init_sema(&i2s_rx_sema, 0);
	if(xTaskCreate(i2s_rx_thread, ((const char*)"audio_rx_thread"), 1024, NULL, tskIDLE_PRIORITY + 6, NULL) != pdPASS)
		DUER_LOGE("Create audio_rx_thread failed!");

	initialize_audio_as_recorder();

	rtw_init_sema(&audio_pause_sema, 0);
	rtw_init_sema(&audio_resume_sema, 0);

	mp3 = mp3_create();
	if(!mp3)
	{
		DUER_LOGE("MP3 context create failed.\n");
	}

	if(xTaskCreate(play_tone_thread, ((const char*)"play_tone_thread"), 1024, NULL, tskIDLE_PRIORITY + 5, NULL) != pdPASS)
		DUER_LOGE("Create example play_tone_thread failed!");
	
	DUER_LOGI("Audio codec initialized.\n");
}

