#include "duerapp_audio.h"

/**
  * @brief  Execute some operations when audio starts to play
  * @param  None
  * @retval None
  */
void audio_player_start();

/**
  * @brief  Execute some operations when audio stop playing
  * @param  None
  * @retval None
  * @Note   It is necessary to initialize audio as recorder after playing music
  */
void audio_player_stop();

/**
  * @brief  Tx PCM data to codec
  * @param  buf: pointer to buffer which keep the pcm data
  * @param  len: length of pcm data to be transmitted
  * @retval None
  */
void audio_play_pcm(char *buf, int len);

/**
  * @brief  Initializes the interface with codec to be able to tx data
  * @param  para: pointer to a player_t structure which stores initialization parameters
  * @retval can be 0 or -1:
  *          0:  Init success
  *          -1: Init fail
  */
int initialize_audio_as_player(player_t *para);

