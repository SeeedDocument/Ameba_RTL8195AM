// Copyright (2017) Baidu Inc. All rights reserved.
/**
 * File: duerapp.c
 * Auth: Su Hao(suhao@baidu.com)
 * Desc: Duer Application Main.
 */

//#include <string.h>
#include "FreeRTOS.h"
#include "task.h"

#include "lightduer_connagent.h"
#include "lightduer_voice.h"
#include "lightduer_timers.h"
#include "lightduer_play_event.h"
#include "lightduer_key.h"
#include "lightduer_voice.h"
#include "lightduer_net_ntp.h"

#include "duerapp_config.h"
#include "lightduer_memory.h"
#include "section_config.h"
#include "duerapp_audio.h"

#define PROFILE_PATH    SDCARD_PATH"/profile"

#define VOICE_FROM_AUDIO_CODEC	1
#define VOICE_FROM_SDCARD			0
#define PROFILE_FROM_SDCARD			0

static TaskHandle_t xHandle = NULL;
duer_timer_handler g_restart_timer = NULL;

u8 duer_engine_is_stopped = 0;

#define DUER_PROFILE_UUID	5  //Range: 5,6,7,8,9
#if (PROFILE_FROM_SDCARD == 0)
#if (DUER_PROFILE_UUID == 5)
SDRAM_DATA_SECTION static const char duer_profile[]=
"{\"configures\":\"{}\",\"bindToken\":\"babfd6add70bcfc83cbd9341bbbc52f3\",\"coapPort\":443,\
\"token\":\"jRJG498X\",\"serverAddr\":\"device.iot.baidu.com\",\"lwm2mPort\":443,\
\"uuid\":\"087c0000000005\",\"rsaCaCrt\":\"-----BEGIN CERTIFICATE-----\\n\
MIIDUDCCAjgCCQCmVPUErMYmCjANBgkqhkiG9w0BAQUFADBqMQswCQYDVQQGEwJD\\n\
TjETMBEGA1UECAwKU29tZS1TdGF0ZTEOMAwGA1UECgwFYmFpZHUxGDAWBgNVBAMM\\n\
DyouaW90LmJhaWR1LmNvbTEcMBoGCSqGSIb3DQEJARYNaW90QGJhaWR1LmNvbTAe\\n\
Fw0xNjAzMTEwMzMwNDlaFw0yNjAzMDkwMzMwNDlaMGoxCzAJBgNVBAYTAkNOMRMw\\n\
EQYDVQQIDApTb21lLVN0YXRlMQ4wDAYDVQQKDAViYWlkdTEYMBYGA1UEAwwPKi5p\\n\
b3QuYmFpZHUuY29tMRwwGgYJKoZIhvcNAQkBFg1pb3RAYmFpZHUuY29tMIIBIjAN\\n\
BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtbhIeiN7pznzuMwsLKQj2xB02+51\\n\
OvCJ5d116ZFLjecp9qtllqOfN7bm+AJa5N2aAHJtsetcTHMitY4dtGmOpw4dlGqx\\n\
luoz50kWJWQjVR+z6DLPnGE4uELOS8vbKHUoYPPQTT80eNVnl9S9h/l7DcjEAJYC\\n\
IYJbf6+K9x+Ti9VRChvWcvgZQHMRym9j1g/7CKGMCIwkC+6ihkGD/XG40r7KRCyH\\n\
bD53KnBjBO9FH4IL3rGlZWKWzMw3zC6RTS2ekfEsgAtYDvROKd4rNs+uDU9xaBLO\\n\
dXTl5uxgudH2VnVzWtj09OUbBtXcQFD2IhmOl20BrckYul+HEIMR0oDibwIDAQAB\\n\
MA0GCSqGSIb3DQEBBQUAA4IBAQCzTTH91jNh/uYBEFekSVNg1h1kPSujlwEDDf/W\\n\
pjqPJPqrZvW0w0cmYsYibNDy985JB87MJMfJVESG/v0Y/YbvcnRoi5gAenWXQNL4\\n\
h2hf08A5wEQfLO/EaD1GTH3OIierKYZ6GItGrz4uFKHV5fTMiflABCdu37ALGjrA\\n\
rIjwjxQG6WwLr9468hkKrWNG3dMBHKvmqO8x42sZOFRJMkqBbKzaBd1uW4xY5XwM\\n\
S1QX56tVrgO0A3S+4dEg5uiLVN4YVP/Vqh4SMtYkL7ZZiZAxD9GtNnhRyFsWlC2r\\n\
OVSdXs1ttZxEaEBGUl7tgsBte556BIvufZX+BXGyycVJdBu3\\n\
-----END CERTIFICATE-----\\n\",\"macId\":\"\",\"version\":3048}";

#elif (DUER_PROFILE_UUID == 6)
SDRAM_DATA_SECTION static const char duer_profile[]=
"{\"configures\":\"{}\",\"bindToken\":\"379979429fad5d2504c27b8fcf533dca\",\"coapPort\":443,\
\"token\":\"AWb8nsaC\",\"serverAddr\":\"device.iot.baidu.com\",\"lwm2mPort\":443,\
\"uuid\":\"087c0000000006\",\"rsaCaCrt\":\"-----BEGIN CERTIFICATE-----\\n\
MIIDUDCCAjgCCQCmVPUErMYmCjANBgkqhkiG9w0BAQUFADBqMQswCQYDVQQGEwJD\\n\
TjETMBEGA1UECAwKU29tZS1TdGF0ZTEOMAwGA1UECgwFYmFpZHUxGDAWBgNVBAMM\\n\
DyouaW90LmJhaWR1LmNvbTEcMBoGCSqGSIb3DQEJARYNaW90QGJhaWR1LmNvbTAe\\n\
Fw0xNjAzMTEwMzMwNDlaFw0yNjAzMDkwMzMwNDlaMGoxCzAJBgNVBAYTAkNOMRMw\\n\
EQYDVQQIDApTb21lLVN0YXRlMQ4wDAYDVQQKDAViYWlkdTEYMBYGA1UEAwwPKi5p\\n\
b3QuYmFpZHUuY29tMRwwGgYJKoZIhvcNAQkBFg1pb3RAYmFpZHUuY29tMIIBIjAN\\n\
BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtbhIeiN7pznzuMwsLKQj2xB02+51\\n\
OvCJ5d116ZFLjecp9qtllqOfN7bm+AJa5N2aAHJtsetcTHMitY4dtGmOpw4dlGqx\\n\
luoz50kWJWQjVR+z6DLPnGE4uELOS8vbKHUoYPPQTT80eNVnl9S9h/l7DcjEAJYC\\n\
IYJbf6+K9x+Ti9VRChvWcvgZQHMRym9j1g/7CKGMCIwkC+6ihkGD/XG40r7KRCyH\\n\
bD53KnBjBO9FH4IL3rGlZWKWzMw3zC6RTS2ekfEsgAtYDvROKd4rNs+uDU9xaBLO\\n\
dXTl5uxgudH2VnVzWtj09OUbBtXcQFD2IhmOl20BrckYul+HEIMR0oDibwIDAQAB\\n\
MA0GCSqGSIb3DQEBBQUAA4IBAQCzTTH91jNh/uYBEFekSVNg1h1kPSujlwEDDf/W\\n\
pjqPJPqrZvW0w0cmYsYibNDy985JB87MJMfJVESG/v0Y/YbvcnRoi5gAenWXQNL4\\n\
h2hf08A5wEQfLO/EaD1GTH3OIierKYZ6GItGrz4uFKHV5fTMiflABCdu37ALGjrA\\n\
rIjwjxQG6WwLr9468hkKrWNG3dMBHKvmqO8x42sZOFRJMkqBbKzaBd1uW4xY5XwM\\n\
S1QX56tVrgO0A3S+4dEg5uiLVN4YVP/Vqh4SMtYkL7ZZiZAxD9GtNnhRyFsWlC2r\\n\
OVSdXs1ttZxEaEBGUl7tgsBte556BIvufZX+BXGyycVJdBu3\\n\
-----END CERTIFICATE-----\\n\",\"macId\":\"\",\"version\":3048}";

#elif (DUER_PROFILE_UUID == 7)
SDRAM_DATA_SECTION static const char duer_profile[]=
"{\"configures\":\"{}\",\"bindToken\":\"844bb5ec1f1846cf4fa90ccc1053485e\",\"coapPort\":443,\
\"token\":\"NNbUfh6d\",\"serverAddr\":\"device.iot.baidu.com\",\"lwm2mPort\":443,\
\"uuid\":\"087c0000000007\",\"rsaCaCrt\":\"-----BEGIN CERTIFICATE-----\\n\
MIIDUDCCAjgCCQCmVPUErMYmCjANBgkqhkiG9w0BAQUFADBqMQswCQYDVQQGEwJD\\n\
TjETMBEGA1UECAwKU29tZS1TdGF0ZTEOMAwGA1UECgwFYmFpZHUxGDAWBgNVBAMM\\n\
DyouaW90LmJhaWR1LmNvbTEcMBoGCSqGSIb3DQEJARYNaW90QGJhaWR1LmNvbTAe\\n\
Fw0xNjAzMTEwMzMwNDlaFw0yNjAzMDkwMzMwNDlaMGoxCzAJBgNVBAYTAkNOMRMw\\n\
EQYDVQQIDApTb21lLVN0YXRlMQ4wDAYDVQQKDAViYWlkdTEYMBYGA1UEAwwPKi5p\\n\
b3QuYmFpZHUuY29tMRwwGgYJKoZIhvcNAQkBFg1pb3RAYmFpZHUuY29tMIIBIjAN\\n\
BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtbhIeiN7pznzuMwsLKQj2xB02+51\\n\
OvCJ5d116ZFLjecp9qtllqOfN7bm+AJa5N2aAHJtsetcTHMitY4dtGmOpw4dlGqx\\n\
luoz50kWJWQjVR+z6DLPnGE4uELOS8vbKHUoYPPQTT80eNVnl9S9h/l7DcjEAJYC\\n\
IYJbf6+K9x+Ti9VRChvWcvgZQHMRym9j1g/7CKGMCIwkC+6ihkGD/XG40r7KRCyH\\n\
bD53KnBjBO9FH4IL3rGlZWKWzMw3zC6RTS2ekfEsgAtYDvROKd4rNs+uDU9xaBLO\\n\
dXTl5uxgudH2VnVzWtj09OUbBtXcQFD2IhmOl20BrckYul+HEIMR0oDibwIDAQAB\\n\
MA0GCSqGSIb3DQEBBQUAA4IBAQCzTTH91jNh/uYBEFekSVNg1h1kPSujlwEDDf/W\\n\
pjqPJPqrZvW0w0cmYsYibNDy985JB87MJMfJVESG/v0Y/YbvcnRoi5gAenWXQNL4\\n\
h2hf08A5wEQfLO/EaD1GTH3OIierKYZ6GItGrz4uFKHV5fTMiflABCdu37ALGjrA\\n\
rIjwjxQG6WwLr9468hkKrWNG3dMBHKvmqO8x42sZOFRJMkqBbKzaBd1uW4xY5XwM\\n\
S1QX56tVrgO0A3S+4dEg5uiLVN4YVP/Vqh4SMtYkL7ZZiZAxD9GtNnhRyFsWlC2r\\n\
OVSdXs1ttZxEaEBGUl7tgsBte556BIvufZX+BXGyycVJdBu3\\n\
-----END CERTIFICATE-----\\n\",\"macId\":\"\",\"version\":3048}";

#elif (DUER_PROFILE_UUID == 8)
SDRAM_DATA_SECTION static const char duer_profile[]=
"{\"configures\":\"{}\",\"bindToken\":\"3e300a435db22aed92c995ff4b0235c4\",\"coapPort\":443,\
\"token\":\"1cRdRNzc\",\"serverAddr\":\"device.iot.baidu.com\",\"lwm2mPort\":443,\
\"uuid\":\"087c0000000008\",\"rsaCaCrt\":\"-----BEGIN CERTIFICATE-----\\n\
MIIDUDCCAjgCCQCmVPUErMYmCjANBgkqhkiG9w0BAQUFADBqMQswCQYDVQQGEwJD\\n\
TjETMBEGA1UECAwKU29tZS1TdGF0ZTEOMAwGA1UECgwFYmFpZHUxGDAWBgNVBAMM\\n\
DyouaW90LmJhaWR1LmNvbTEcMBoGCSqGSIb3DQEJARYNaW90QGJhaWR1LmNvbTAe\\n\
Fw0xNjAzMTEwMzMwNDlaFw0yNjAzMDkwMzMwNDlaMGoxCzAJBgNVBAYTAkNOMRMw\\n\
EQYDVQQIDApTb21lLVN0YXRlMQ4wDAYDVQQKDAViYWlkdTEYMBYGA1UEAwwPKi5p\\n\
b3QuYmFpZHUuY29tMRwwGgYJKoZIhvcNAQkBFg1pb3RAYmFpZHUuY29tMIIBIjAN\\n\
BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtbhIeiN7pznzuMwsLKQj2xB02+51\\n\
OvCJ5d116ZFLjecp9qtllqOfN7bm+AJa5N2aAHJtsetcTHMitY4dtGmOpw4dlGqx\\n\
luoz50kWJWQjVR+z6DLPnGE4uELOS8vbKHUoYPPQTT80eNVnl9S9h/l7DcjEAJYC\\n\
IYJbf6+K9x+Ti9VRChvWcvgZQHMRym9j1g/7CKGMCIwkC+6ihkGD/XG40r7KRCyH\\n\
bD53KnBjBO9FH4IL3rGlZWKWzMw3zC6RTS2ekfEsgAtYDvROKd4rNs+uDU9xaBLO\\n\
dXTl5uxgudH2VnVzWtj09OUbBtXcQFD2IhmOl20BrckYul+HEIMR0oDibwIDAQAB\\n\
MA0GCSqGSIb3DQEBBQUAA4IBAQCzTTH91jNh/uYBEFekSVNg1h1kPSujlwEDDf/W\\n\
pjqPJPqrZvW0w0cmYsYibNDy985JB87MJMfJVESG/v0Y/YbvcnRoi5gAenWXQNL4\\n\
h2hf08A5wEQfLO/EaD1GTH3OIierKYZ6GItGrz4uFKHV5fTMiflABCdu37ALGjrA\\n\
rIjwjxQG6WwLr9468hkKrWNG3dMBHKvmqO8x42sZOFRJMkqBbKzaBd1uW4xY5XwM\\n\
S1QX56tVrgO0A3S+4dEg5uiLVN4YVP/Vqh4SMtYkL7ZZiZAxD9GtNnhRyFsWlC2r\\n\
OVSdXs1ttZxEaEBGUl7tgsBte556BIvufZX+BXGyycVJdBu3\\n\
-----END CERTIFICATE-----\\n\",\"macId\":\"\",\"version\":3048}";

#elif (DUER_PROFILE_UUID == 9)
SDRAM_DATA_SECTION static const char duer_profile[]=
"{\"configures\":\"{}\",\"bindToken\":\"6567f68c186b703a33eeace4d63236a4\",\"coapPort\":443,\
\"token\":\"2AQ5XG0T\",\"serverAddr\":\"device.iot.baidu.com\",\"lwm2mPort\":443,\
\"uuid\":\"087c0000000009\",\"rsaCaCrt\":\"-----BEGIN CERTIFICATE-----\\n\
MIIDUDCCAjgCCQCmVPUErMYmCjANBgkqhkiG9w0BAQUFADBqMQswCQYDVQQGEwJD\\n\
TjETMBEGA1UECAwKU29tZS1TdGF0ZTEOMAwGA1UECgwFYmFpZHUxGDAWBgNVBAMM\\n\
DyouaW90LmJhaWR1LmNvbTEcMBoGCSqGSIb3DQEJARYNaW90QGJhaWR1LmNvbTAe\\n\
Fw0xNjAzMTEwMzMwNDlaFw0yNjAzMDkwMzMwNDlaMGoxCzAJBgNVBAYTAkNOMRMw\\n\
EQYDVQQIDApTb21lLVN0YXRlMQ4wDAYDVQQKDAViYWlkdTEYMBYGA1UEAwwPKi5p\\n\
b3QuYmFpZHUuY29tMRwwGgYJKoZIhvcNAQkBFg1pb3RAYmFpZHUuY29tMIIBIjAN\\n\
BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtbhIeiN7pznzuMwsLKQj2xB02+51\\n\
OvCJ5d116ZFLjecp9qtllqOfN7bm+AJa5N2aAHJtsetcTHMitY4dtGmOpw4dlGqx\\n\
luoz50kWJWQjVR+z6DLPnGE4uELOS8vbKHUoYPPQTT80eNVnl9S9h/l7DcjEAJYC\\n\
IYJbf6+K9x+Ti9VRChvWcvgZQHMRym9j1g/7CKGMCIwkC+6ihkGD/XG40r7KRCyH\\n\
bD53KnBjBO9FH4IL3rGlZWKWzMw3zC6RTS2ekfEsgAtYDvROKd4rNs+uDU9xaBLO\\n\
dXTl5uxgudH2VnVzWtj09OUbBtXcQFD2IhmOl20BrckYul+HEIMR0oDibwIDAQAB\\n\
MA0GCSqGSIb3DQEBBQUAA4IBAQCzTTH91jNh/uYBEFekSVNg1h1kPSujlwEDDf/W\\n\
pjqPJPqrZvW0w0cmYsYibNDy985JB87MJMfJVESG/v0Y/YbvcnRoi5gAenWXQNL4\\n\
h2hf08A5wEQfLO/EaD1GTH3OIierKYZ6GItGrz4uFKHV5fTMiflABCdu37ALGjrA\\n\
rIjwjxQG6WwLr9468hkKrWNG3dMBHKvmqO8x42sZOFRJMkqBbKzaBd1uW4xY5XwM\\n\
S1QX56tVrgO0A3S+4dEg5uiLVN4YVP/Vqh4SMtYkL7ZZiZAxD9GtNnhRyFsWlC2r\\n\
OVSdXs1ttZxEaEBGUl7tgsBte556BIvufZX+BXGyycVJdBu3\\n\
-----END CERTIFICATE-----\\n\",\"macId\":\"\",\"version\":3048}";
#endif
#endif	

#if VOICE_FROM_SDCARD
static void duer_test_task(void *pvParameters);
#endif
static void duer_record_event_callback(int event, const void *data, size_t size)
{
    switch (event) {
    case REC_START:
    {
        DUER_LOGD("start send voice: %s", (const char *)data);
        baidu_json *path = baidu_json_CreateObject();
        baidu_json_AddStringToObject(path, "path", (const char *)data);
        duer_data_report(path);
        baidu_json_Delete(path);
        duer_voice_start(16000);
        break;
    }
    case REC_DATA:
        duer_voice_send(data, size);
        break;
    case REC_STOP:
        DUER_LOGD("stop send voice: %s", (const char *)data);
        duer_voice_stop();
        break;
    default:
        DUER_LOGE("event not supported: %d!", event);
        break;
    }
}

static void duer_event_hook(duer_event_t *event)
{
    if (!event) {
        DUER_LOGE("NULL event!!!");
    }

    DUER_LOGI("event: %d", event->_event);

    switch (event->_event) {
    case DUER_EVENT_STARTED:
#if VOICE_FROM_SDCARD		
        xTaskCreate(&duer_test_task, "duer_test_task", 4096, NULL, 5, &xHandle);
#endif
#if VOICE_FROM_AUDIO_CODEC
        duer_record_set_event_callback(duer_record_event_callback);
#endif
        duerapp_gpio_led_mode(DUER_LED_OFF);
        duer_engine_is_stopped = 0;
        break;
    case DUER_EVENT_STOPPED:
        duer_engine_is_stopped = 1;
        if (xHandle) {
            vTaskDelete(xHandle);
            xHandle = NULL;
        }
        break;
    }
}

extern u8 voice_is_triggered;
extern u8 audio_is_playing;
extern u8 audio_is_pocessing;
extern void http_download_thread(void *param);
extern QueueHandle_t voice_result_queue;
extern int duer_init_play(void);

static void duer_voice_play_by_uri(baidu_json *uri)
{	
	baidu_json *mp3_url = baidu_json_GetObjectItem(uri, "url");
	baidu_json *payload = baidu_json_GetObjectItem(uri, "payload");
	baidu_json *payload_url = NULL;
	baidu_json *speech = baidu_json_GetObjectItem(uri, "speech");
	baidu_json *speech_url = NULL;
	
	char *url = NULL;

	if(payload){
		payload_url = baidu_json_GetObjectItem(payload, "url");
	}

	if(speech){
		speech_url = baidu_json_GetObjectItem(speech, "url");
	}	
	
	if(mp3_url && strstr( mp3_url->valuestring, ".mp3"))
	{
		DUER_LOGD("mp3 uri: %s", mp3_url->valuestring);
		url = DUER_MALLOC(strlen(mp3_url->valuestring)+1);
		if(url)
			strcpy(url, mp3_url->valuestring);
	}else if(payload_url && strstr( payload_url->valuestring, ".mp3")){
		DUER_LOGD("payload uri: %s", payload_url->valuestring);
		url = DUER_MALLOC(strlen(payload_url->valuestring)+1);
		if(url)
			strcpy(url, payload_url->valuestring);
	}else if(speech_url && strstr( speech_url->valuestring, ".mp3")){
		DUER_LOGD("speech uri: %s", speech_url->valuestring);
		url = DUER_MALLOC(strlen(speech_url->valuestring)+1);
		if(url)
			strcpy(url, speech_url->valuestring);		
	}

	if(url){
		if(voice_is_triggered == 0 && audio_is_playing == 0 && audio_is_pocessing == 0){
		if(xTaskCreate(http_download_thread, ((const char*)"http_download_thread"), 1024, url, tskIDLE_PRIORITY + 1, NULL) != pdPASS)
			DUER_LOGE("Create http download thread failed!");
		}else{
			DUER_LOGI("voice_is_triggered:%d, audio_is_playing:%d, audio_is_pocessing:%d", voice_is_triggered, audio_is_playing, audio_is_pocessing);
			if(url)
				DUER_FREE(url);
		}
	}else{
		DUER_LOGE("duer_voice_result no mp3 URL found, uri: %s", uri->string);	
		goto CannotPlay;
	}
	
	return;
	
CannotPlay:
	tone_enqueue(TONE_CANNOTPLAY);
}

static void duer_voice_result(struct baidu_json *result)
{	
    BaseType_t ret;
    baidu_json *voice_result = NULL;

#if 0
    voice_result = baidu_json_Duplicate(result, 1);
    if (voice_result == NULL) {
        DUER_LOGE("Duplication voice result failed");

        return;
    }
#endif

    duer_voice_play_by_uri(result);

    duer_set_play_source(PLAY_NET_FILE);

#if 0
    ret = xQueueSendToFront(voice_result_queue, voice_result, 0);
    if (ret != pdTRUE) {
        DUER_LOGE("Send voice result failed");

        baidu_json_Delete(voice_result);
    }
#endif	
}

static void duer_set_volume_result(int result)
{
    //TODO: set valume here
    switch(result){
        case -1:
            duerapp_play_mp3_volume_down();
            break;
        case 0:
            duerapp_play_mp3_volume_min();
            break;
        case 1:
            duerapp_play_mp3_volume_up();
            break;
        case 16:
            duerapp_play_mp3_volume_max();
            break;
        default:
            DUER_LOGW("bad volume!!");
    }
}


#if VOICE_FROM_SDCARD
void duer_test_task(void *pvParameters)
{
    (void)pvParameters;

    duer_record_set_event_callback(duer_record_event_callback);

    while (1) {
        duer_record_all();
        vTaskDelay(20000 / portTICK_PERIOD_MS);
    }
}
#endif

// It called in duerapp_wifi_config.c, when the Wi-Fi is connected.
void duer_test_start()
{
#if PROFILE_FROM_SDCARD
    const char *data = duer_load_profile(PROFILE_PATH);
    if (data == NULL) {
        DUER_LOGE("load profile failed!");
        return;
    }

    DUER_LOGD("profile: \n%s", data);

    // We start the duer with duer_start(), when network connected.
    duer_start(data, strlen(data));

    free((void *)data);
#else
    // We start the duer with duer_start(), when network connected.
    duer_start(duer_profile, strlen(duer_profile));

#endif
}

static void duer_restart_timer_expired(void *param)
{
    sys_reset();
}

static TaskHandle_t xNtpHandle = NULL;
void ntp_task() {
    DuerTime time;
    int ret = -1;

    vTaskDelay(5000 / portTICK_PERIOD_MS); // wait network ready

    ret = duer_ntp_client(NULL, 0, &time);

    while (ret < 0) {
        ret = duer_ntp_client(NULL, 0, &time);
    }

    if (xNtpHandle) {
        vTaskDelete(xNtpHandle);
        xNtpHandle = NULL;
    }
}
static void get_ntp_time() {
    xTaskCreate(&ntp_task, "ntp_task", 4096, NULL, 5, &xNtpHandle);
}


void example_duer_thread()
{
    initialize_wifi();

#if (PROFILE_FROM_SDCARD || VOICE_FROM_SDCARD)
    initialize_sdcard();
#endif

    initialize_audio();

    initialize_sdcard_record();

    //initialize_peripheral();
	
    //get NTP time
    get_ntp_time();
	
    // Initialize the Duer OS
    duer_initialize();

    // Initialize the alarm
    duer_init_alarm();

    // Initialize play event
    duer_init_play();	

    // Set the Duer Event Callback
    duer_set_event_callback(duer_event_hook);

    // Set the voice interaction result
    duer_voice_set_result_callback(duer_voice_result);

    // Set the valume interaction result
    duer_voice_set_volume_callback(duer_set_volume_result);

    g_restart_timer = duer_timer_acquire(duer_restart_timer_expired, NULL, DUER_TIMER_ONCE);
	
    duer_test_start();

    vTaskDelete(NULL);
}

void example_duer()
{
	if(xTaskCreate(example_duer_thread, ((const char*)"example_duer_thread"), 1024, NULL, tskIDLE_PRIORITY + 1, NULL) != pdPASS)
		DUER_LOGE("Create example duer thread failed!");
}

