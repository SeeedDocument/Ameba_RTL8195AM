#include "duerapp_audio.h"
#include "duerapp_alc5680_record.h"

#include "FreeRTOS.h"
#include "semphr.h"

SDRAM_BSS_SECTION unsigned char i2s_comm_buf[I2S_MAX_DMA_PAGE_SIZE*I2S_DMA_PAGE_NUM];
SDRAM_BSS_SECTION static unsigned char i2s_rx_history[I2S_RX_HISTORY_SIZE][I2S_RX_PAGE_SIZE];

char *path = "/Ameba_voice";
i2s_t i2s_obj;
static record_t record_obj;
static record_para_t record_para = {0, 75, 300, 100, TRUE};
extern u8 audio_is_pocessing;
extern u8 voice_is_triggered;
_sema i2s_rx_sema = NULL;
static char* i2s_rx_pbuf;

#define VOLUME_UP_CONDITION			(volume > (record_obj.bkg_avg_vol * 2) && volume > record_para.base_vol_thres)
#define VOLUME_DOWN_CONDITION_1		(volume < (record_obj.bkg_avg_vol*4))
#define VOLUME_DOWN_CONDITION_2		(volume < ((cmd_avg_vol - record_obj.bkg_avg_vol) * 4 / 10) + record_obj.bkg_avg_vol)

extern int duer_sdcard_send(int type, const void *data, size_t size);

static void i2s_recoder_rx_complete(void *data, char* pbuf)
{
	i2s_rx_pbuf = pbuf;
	xSemaphoreGiveFromISR(i2s_rx_sema, NULL);
}

void i2s_rx_thread(void* param)
{
	u8 action;
	int32_t volume = 0, i;
	int16_t *pdata;
	u32 cur_time;
	int cmd_avg_vol = 0;

	record_obj.bkg_avg_vol = 0;

	while(1){
		if(xSemaphoreTake(i2s_rx_sema, 0xFFFFFFFF) != pdTRUE) continue;

		action = AUDIO_RX_IDLE;
		cur_time = xTaskGetTickCount();
		pdata = (int16_t *)i2s_rx_pbuf;

		i2s_recv_page(&i2s_obj);

		// calculate volume
		for(i = 0; i < I2S_RX_PAGE_SIZE / 2; i++){
			volume += (pdata[i] > 0) ? pdata[i] : -pdata[i];
		}
		volume /= (I2S_RX_PAGE_SIZE / 2);

		if(!audio_is_pocessing){
			if(record_obj.bkg_avg_vol == 0)
				record_obj.bkg_avg_vol = volume;

			record_obj.bkg_avg_vol = ((record_obj.bkg_avg_vol * 255) + volume) / 256;
			continue;
		}

		record_obj.skip_pages++;
		if(record_obj.skip_pages > SKIP_PAGE_NUM){
			if(record_obj.is_recording){
				if(record_para.detect_voice_stop != FALSE){
					if (record_obj.audio_record_start_timestamp + 500  > cur_time) {
						action = AUDIO_RX_PROCESSING;
					} else {
						if (record_obj.cmd_vol_count >= 10) {
							cmd_avg_vol = record_obj.total_cmd_vol / record_obj.cmd_vol_count;
							record_obj.silent_count = VOLUME_DOWN_CONDITION_2 ? (record_obj.silent_count + 1) : 0;
						}
						else
							record_obj.silent_count = VOLUME_DOWN_CONDITION_1 ? (record_obj.silent_count + 1) : 0;
						
						action = (record_obj.silent_count > record_para.max_silent_cnt) ? AUDIO_RX_END : AUDIO_RX_PROCESSING;
					}
				}else
					action = AUDIO_RX_PROCESSING;
			}else{
				// save audio data into history buffer
				_memcpy(i2s_rx_history[record_obj.i2s_rx_history_idx++], i2s_rx_pbuf, I2S_RX_PAGE_SIZE);
				if(record_obj.i2s_rx_history_idx == I2S_RX_HISTORY_SIZE)
					record_obj.i2s_rx_history_idx = 0;
				
				if(VOLUME_UP_CONDITION){
					record_obj.is_recording = 1;
					action = AUDIO_RX_EARLY_PROCESSING;
					DUER_LOGI("Start to record voice command. Current volume:%d,average volume:%d.", volume, record_obj.bkg_avg_vol);
				}else{
					// no sound over 8 seconds, stop
					if(record_obj.audio_record_start_timestamp + record_obj.audio_record_timeout < cur_time){
						action = AUDIO_RX_END;
						DUER_LOGI("No sound for 8 sec, stop recording.");

						tone_enqueue(TONE_CANNOTHEARD);
					}
				}
			}

			if((record_obj.record_length + I2S_RX_PAGE_SIZE) >= RECORD_LEN){
				action = AUDIO_RX_END;
			}
				
			switch(action){
			case AUDIO_RX_EARLY_PROCESSING:
				duer_record_event(REC_START, path, 0);
				duer_sdcard_send(REC_START, NULL, 0);
				for(i = 0; i < I2S_RX_HISTORY_SIZE; i++){
					duer_record_event(REC_DATA, i2s_rx_history[(record_obj.i2s_rx_history_idx + i)% I2S_RX_HISTORY_SIZE], I2S_RX_PAGE_SIZE);
					duer_sdcard_send(REC_DATA, i2s_rx_history[(record_obj.i2s_rx_history_idx + i)% I2S_RX_HISTORY_SIZE], I2S_RX_PAGE_SIZE);			
					record_obj.record_length += I2S_RX_PAGE_SIZE;
				}
				record_obj.cmd_vol_count = 0;
				record_obj.total_cmd_vol = 0;
			break;
			case AUDIO_RX_PROCESSING:
				duer_record_event(REC_DATA, i2s_rx_pbuf, I2S_RX_PAGE_SIZE);
				duer_sdcard_send(REC_DATA, i2s_rx_pbuf, I2S_RX_PAGE_SIZE);			
				record_obj.record_length += I2S_RX_PAGE_SIZE;
				
				if(VOLUME_UP_CONDITION){
					record_obj.total_cmd_vol += volume;
					record_obj.cmd_vol_count ++;
				}
			break;
			case AUDIO_RX_END:
				DUER_LOGI("Record total length is %d\n",record_obj.record_length);
				duer_record_event(REC_STOP, path, 0);
				duer_sdcard_send(REC_STOP, NULL, record_obj.record_length);				
				audio_record_stop();
			case AUDIO_RX_IDLE:
			default:
			break;
			
			}
		}
	}
}

/**
  * @brief  Execute some operations when start to record
  * @param  timeout_ms: Period to be silent before stop recording
  * @retval None
  * @Note   It is necessary to set audio_is_pocessing to 1 in this function
  */
void audio_record_start(uint32_t timeout_ms)
{
	int i = 0;

	record_obj.volume_max = 0;
	record_obj.silent_count = 0;
	record_obj.is_recording = 0;
	record_obj.audio_record_start_timestamp = xTaskGetTickCountFromISR();
	record_obj.audio_record_timeout = timeout_ms;
	record_obj.skip_pages = 0;

	record_obj.record_length = 0;
	record_obj.i2s_rx_history_idx = 0;

	for(; i < I2S_RX_HISTORY_SIZE; i++){
		_memset(i2s_rx_history[i], I2S_RX_PAGE_SIZE, 0);
	}

	duerapp_gpio_led_mode(DUER_LED_ON);

	audio_is_pocessing = 1;
	voice_is_triggered = 0;
}


/**
  * @brief  Execute some operations when stop recording
  * @param  None
  * @retval None
  * @Note   It is necessary to reset audio_is_pocessing to 0 in this function
  */
void audio_record_stop()
{
	duerapp_gpio_led_mode(DUER_LED_OFF);
	audio_is_pocessing = 0;
}

/**
  * @brief  Initializes the interface with codec to be able to rx data
  * @param  None
  * @retval 0: Init success
  */
int initialize_audio_as_recorder()
{
	DUER_LOGI("Initialize audio as recorder.");

	i2s_obj.channel_num = I2S_CH_MONO;
	i2s_obj.sampling_rate = SR_16KHZ;
	i2s_obj.word_length = WL_16b;
	i2s_obj.direction = I2S_DIR_RX;    
	i2s_init(&i2s_obj, I2S_SCLK_PIN, I2S_WS_PIN, I2S_SD_PIN);
	i2s_set_dma_buffer(&i2s_obj, NULL, (char*)i2s_comm_buf, I2S_DMA_PAGE_NUM, I2S_RX_PAGE_SIZE);
	i2s_rx_irq_handler(&i2s_obj, (i2s_irq_handler)i2s_recoder_rx_complete, (uint32_t)&i2s_obj);

	i2s_recv_page(&i2s_obj);
	return 0;
}

u32 get_base_vol_threshold()
{
	return record_para.base_vol_thres;
}

void set_base_vol_threshold(u32 value)
{
	record_para.base_vol_thres = value;
}

u32 get_vol_up_threshold()
{
	return record_para.vol_up_thres;
}

void set_vol_up_threshold(u32 value)
{
	record_para.vol_up_thres = value;
}

u32 get_max_silent_cnt()
{
	return record_para.max_silent_cnt;
}

void set_max_silent_cnt(u32 value)
{
	record_para.max_silent_cnt = value;
}

u32 get_detect_voice_stop()
{
	return record_para.detect_voice_stop;
}

void set_detect_voice_stop(bool state)
{
	record_para.detect_voice_stop = state;
}

