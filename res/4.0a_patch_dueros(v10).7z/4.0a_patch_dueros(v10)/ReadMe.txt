Patch Description

This Patch is for DuerOS.

Useage:
    Copy all the directories in the patch to cover the old ones and replace the same files if they are already existed.

Notes:
    The patch has been verified in sdk-ameba-v4.0a_without_NDA.